
How to use this theme
---------------------

Add the following line inside your <head> tag _AFTER_ the
webcomponents-lite.min.js and other HTML imports:

<link rel="import" href="path/to/sky.html">



Usage within your own custom elements
-------------------------------------

To use this theme within your own custom elements, add the
following line inside your <dom-module> tag in each of your
custom elements:

<link rel="import" href="path/to/sky.css" type="css">
